<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "xtao";  // your user name
	$pwd  = "finish"; // your password
	$sql_db  = "xtao_db";  // your db
?>